(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_Pages_Register"],{

/***/ "./resources/js/Pages/Register":
/*!*************************************!*\
  !*** ./resources/js/Pages/Register ***!
  \*************************************/
/***/ (() => {

throw new Error("Module parse failed: Unexpected token (30:4)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n| \n|   return (\n>     <div class=\"page-wrapper\">\n|         <div class=\"page-content--bge5\">\n|             <div class=\"container\">");

/***/ })

}]);