<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\ujian_react_laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>